import tkinter as tk
from tkinter import scrolledtext, messagebox, simpledialog
import random
import json
import os
import time
from korean_words import words

PROGRESS_FILE = "progress.json"

class FlashcardApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Flash Cards")
        self.root.geometry("900x650")
        self.root.configure(bg="#121212")
        self.root.resizable(False, False)

        self.root.protocol("WM_DELETE_WINDOW", self.quit_app)

        self.original_deck = words.copy()
        self.deck = []
        self.mastered = []
        self.current_word = None
        self.waiting_for_next = False
        self.revealed_answer = False

        self.flip_mode = False  # False = Korean → English, True = English → Korean

        self.is_timed_mode = False
        self.time_limit_seconds = 0
        self.start_time = None
        self.correct_count = 0
        self.total_attempted = 0

        # Build UI only after all methods are defined
        self.build_ui()

        self.load_progress()
        self.update_all_texts()

        if self.deck:
            self.next_card()
        else:
            ready_text = "Ready! 807 unique words loaded." if not self.flip_mode else "준비 완료! 807개 단어 로드됨."
            self.main_word_label.config(text=ready_text)

    # ==================== ALL METHODS DEFINED FIRST ====================

    def build_ui(self):
        main_frame = tk.Frame(self.root, bg="#121212")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        left_frame = tk.Frame(main_frame, bg="#121212")
        left_frame.pack(side="left", fill="both", expand=True)

        self.korean_frame = tk.Frame(left_frame, bg="#1e1e1e", relief="solid", bd=2, width=700, height=300)
        self.korean_frame.pack(pady=(0, 20))
        self.korean_frame.pack_propagate(False)

        self.counter_label = tk.Label(self.korean_frame, text="", font=("Helvetica", 14, "bold"), bg="#1e1e1e", fg="#888888", anchor="nw")
        self.counter_label.place(x=15, y=15)

        self.timer_label = tk.Label(self.korean_frame, text="", font=("Helvetica", 24, "bold"), bg="#1e1e1e", fg="#ff9800", anchor="nw")
        self.timer_label.place(x=15, y=50)

        self.countdown_label = tk.Label(self.korean_frame, text="", font=("Helvetica", 100, "bold"), bg="#1e1e1e", fg="#ffffff")
        self.countdown_label.place(relx=0.5, rely=0.5, anchor="center")

        self.main_word_label = tk.Label(self.korean_frame, text="", font=("Helvetica", 48, "bold"), bg="#1e1e1e", fg="#4da6ff", wraplength=650, justify="center")
        self.main_word_label.place(relx=0.5, rely=0.5, anchor="center")

        self.entry = tk.Entry(left_frame, font=("Helvetica", 24), justify="center", bg="#2d2d2d", fg="#ffffff", insertbackground="#ffffff", relief="flat", bd=10, width=35)
        self.entry.pack(pady=15)
        self.entry.bind("<Return>", self.handle_enter)

        feedback_frame = tk.Frame(left_frame, bg="#121212")
        feedback_frame.pack(pady=20)

        self.feedback_main = tk.Label(feedback_frame, text="", font=("Helvetica", 28, "bold"), bg="#121212", fg="#ff5252")
        self.feedback_main.pack()

        self.feedback_correct_word = tk.Label(feedback_frame, text="", font=("Helvetica", 28, "bold"), bg="#121212", fg="#00e676")
        self.feedback_correct_word.pack()

        self.feedback_sub = tk.Label(feedback_frame, text="", font=("Helvetica", 16), bg="#121212", fg="#ff5252")
        self.feedback_sub.pack(pady=5)

        sidebar = tk.Frame(main_frame, bg="#121212", width=200)
        sidebar.pack(side="right", fill="y", padx=(20, 0))
        sidebar.pack_propagate(False)

        self.controls_label = tk.Label(sidebar, text="Controls", font=("Helvetica", 16, "bold"), bg="#121212", fg="#ffffff")
        self.controls_label.pack(pady=(0, 20))

        btn_style = {"font": ("Helvetica", 11, "bold"), "width": 20, "pady": 8, "relief": "flat", "cursor": "hand2", "bg": "#404040", "fg": "#ffffff", "activebackground": "#505050"}

        self.view_mastered_btn = tk.Button(sidebar, command=self.show_mastered_list, **btn_style)
        self.view_mastered_btn.pack(pady=6)

        self.next_card_btn = tk.Button(sidebar, command=self.next_card_button, **btn_style)
        self.next_card_btn.pack(pady=6)

        self.num_words_btn = tk.Button(sidebar, command=self.select_random_words, **btn_style)
        self.num_words_btn.pack(pady=6)

        self.restart_btn = tk.Button(sidebar, command=self.reset_deck, **btn_style)
        self.restart_btn.pack(pady=6)

        self.timed_btn = tk.Button(sidebar, command=self.start_timed_challenge, **btn_style)
        self.timed_btn.pack(pady=6)

        self.flip_button = tk.Button(sidebar, text="Language / 언어", command=self.toggle_flip_mode, **btn_style)
        self.flip_button.pack(pady=6)

        self.quit_btn = tk.Button(sidebar, command=self.quit_app, **btn_style)
        self.quit_btn.pack(pady=30)

    def update_all_texts(self):
        if self.flip_mode:
            self.controls_label.config(text="컨트롤")
            self.view_mastered_btn.config(text="완료 단어")
            self.next_card_btn.config(text="다음 카드 →")
            self.num_words_btn.config(text="단어 수")
            self.restart_btn.config(text="섞기 & 재시작")
            self.timed_btn.config(text="시간 도전")
            self.quit_btn.config(text="종료")
            self.flip_button.config(bg="#00e676", fg="#000000")
            self.main_word_label.config(fg="#ff9800")
        else:
            self.controls_label.config(text="Controls")
            self.view_mastered_btn.config(text="View Mastered")
            self.next_card_btn.config(text="Next Card →")
            self.num_words_btn.config(text="Number of Words")
            self.restart_btn.config(text="Shuffle & Restart")
            self.timed_btn.config(text="Timed Challenge")
            self.quit_btn.config(text="Quit")
            self.flip_button.config(bg="#404040", fg="#ffffff")
            self.main_word_label.config(fg="#4da6ff")

        self.update_counter()
        self.update_feedback_sub()

    def update_counter(self):
        if self.is_timed_mode:
            text = "Challenge Mode" if not self.flip_mode else "도전 모드"
            color = "#ff9800"
        else:
            remaining = len(self.deck)
            text = f"Remaining: {remaining}" if not self.flip_mode else f"남은 단어: {remaining}"
            color = "#888888"
        self.counter_label.config(text=text, fg=color)

    def update_feedback_sub(self):
        if self.waiting_for_next:
            if self.feedback_main.cget("fg") == "#00e676":
                text = "Press Enter to continue" if not self.flip_mode else "엔터를 눌러 계속"
            else:
                text = "(Added back later) — Press Enter to continue" if not self.flip_mode else "(나중에 다시 나옴) — 엔터를 눌러 계속"
            self.feedback_sub.config(text=text, fg="#888888")
        else:
            self.feedback_sub.config(text="")

    def toggle_flip_mode(self):
        self.flip_mode = not self.flip_mode
        self.update_all_texts()
        if self.current_word:
            self.display_current_word()
        elif self.deck:
            self.next_card()

    def get_prompt_word(self):
        return self.current_word["english"] if self.flip_mode else self.current_word["korean"]

    def get_answer_word(self):
        return self.current_word["korean"] if self.flip_mode else self.current_word["english"]

    def display_current_word(self):
        self.main_word_label.config(text=self.get_prompt_word())
        self.update_counter()
        self.entry.focus_set()
        self.revealed_answer = False

    def handle_enter(self, event=None):
        if self.waiting_for_next:
            self.next_card()
        elif self.entry.get().strip():
            self.check_answer()

    def next_card(self):
        self.waiting_for_next = False
        self.revealed_answer = False
        self.entry.delete(0, tk.END)
        self.feedback_main.config(text="")
        self.feedback_correct_word.config(text="")
        self.feedback_sub.config(text="")

        if not self.deck:
            done_text = "🎉 All done!\nGreat session!" if not self.flip_mode else "🎉 모두 완료!\n좋은 세션이었어요!"
            self.main_word_label.config(text=done_text, fg="#00e676")
            self.update_counter()
            self.current_word = None
            return

        idx = random.randint(0, len(self.deck) - 1)
        self.current_word = self.deck.pop(idx)
        self.display_current_word()

    def next_card_button(self):
        if self.revealed_answer:
            if self.current_word:
                insert_pos = random.randint(max(5, len(self.deck)//4), len(self.deck))
                self.deck.insert(insert_pos, self.current_word)
            self.next_card()
        else:
            if self.current_word:
                answer_text = "Answer:" if not self.flip_mode else "정답:"
                self.feedback_main.config(text=answer_text, fg="#ffffff")
                self.feedback_correct_word.config(text=self.get_answer_word(), fg="#00e676")
                next_text = "Press Next Card again to continue" if not self.flip_mode else "다시 다음 카드 눌러 계속"
                self.feedback_sub.config(text=next_text, fg="#888888")
                self.revealed_answer = True

    def check_answer(self):
        if not self.current_word or self.waiting_for_next:
            return

        self.total_attempted += 1
        user = self.entry.get().strip().lower()
        correct = self.get_answer_word().lower()

        if user == correct:
            self.correct_count += 1
            correct_text = "✓ Correct!" if not self.flip_mode else "✓ 맞았어요!"
            self.feedback_main.config(text=correct_text, fg="#00e676")
            self.feedback_correct_word.config(text="")
            if not self.is_timed_mode:
                if self.current_word not in self.mastered:
                    self.mastered.append(self.current_word)
                self.save_progress()
        else:
            wrong_text = "✗ Wrong" if not self.flip_mode else "✗ 틀렸어요"
            self.feedback_main.config(text=wrong_text, fg="#ff5252")
            self.feedback_correct_word.config(text=self.get_answer_word(), fg="#00e676")
            if not self.is_timed_mode:
                insert_pos = random.randint(max(5, len(self.deck)//4), len(self.deck))
                self.deck.insert(insert_pos, self.current_word)

        self.waiting_for_next = True
        self.update_feedback_sub()
        if not self.is_timed_mode:
            self.update_counter()

    def select_random_words(self):
        title = "Number of Words" if not self.flip_mode else "단어 수"
        prompt = "How many words? (1-807)" if not self.flip_mode else "몇 개의 단어를 선택하시겠어요? (1-807)"

        num = simpledialog.askinteger(title, prompt, parent=self.root, minvalue=1, maxvalue=807)
        if num is None:
            return

        selected = random.sample(self.original_deck, num)
        self.deck = selected.copy()
        random.shuffle(self.deck)
        self.mastered = []
        self.current_word = None
        self.revealed_answer = False
        self.update_counter()
        self.save_progress()
        self.next_card()

        success_msg = f"Selected {num} random words!" if not self.flip_mode else f"{num}개의 단어를 선택했습니다!"
        messagebox.showinfo("Selection Complete" if not self.flip_mode else "선택 완료", success_msg, parent=self.root)

    def show_mastered_list(self):
        if not self.mastered:
            no_msg = "No mastered words yet!" if not self.flip_mode else "아직 완료된 단어가 없어요!"
            messagebox.showinfo("Mastered Words" if not self.flip_mode else "완료 단어", no_msg)
            return

        list_window = tk.Toplevel(self.root)
        list_window.title(f"Mastered Words ({len(self.mastered)})")
        list_window.geometry("500x600")
        list_window.configure(bg="#121212")

        title_text = "Your Mastered Words" if not self.flip_mode else "완료한 단어"
        dir_text = "English → Korean" if self.flip_mode else "Korean → English"
        tk.Label(list_window, text=f"{title_text} ({dir_text})", font=("Helvetica", 18, "bold"), bg="#121212", fg="#00e676").pack(pady=10)

        text_area = scrolledtext.ScrolledText(list_window, font=("Helvetica", 14), bg="#1e1e1e", fg="#ffffff", wrap="word", padx=10, pady=10)
        text_area.pack(fill="both", expand=True, padx=20, pady=10)

        for word in self.mastered:
            line = f"{word['english'].capitalize()} → {word['korean']}" if self.flip_mode else f"{word['korean']} — {word['english'].capitalize()}"
            text_area.insert("end", line + "\n")

        text_area.config(state="disabled")

        close_text = "Close" if not self.flip_mode else "닫기"
        tk.Button(list_window, text=close_text, command=list_window.destroy, font=("Helvetica", 12), bg="#404040", fg="#ffffff").pack(pady=10)

    def start_timed_challenge(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Time Challenge")
        dialog.geometry("320x480")
        dialog.configure(bg="#121212")
        dialog.resizable(False, False)
        dialog.transient(self.root)
        dialog.grab_set()

        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() - 320) // 2
        y = self.root.winfo_y() + (self.root.winfo_height() - 480) // 2
        dialog.geometry(f"+{x}+{y}")

        title_text = "Time Challenge" if not self.flip_mode else "시간 도전"
        tk.Label(dialog, text=title_text, font=("Helvetica", 22, "bold"), bg="#121212", fg="#ff9800").pack(pady=(40, 10))

        instr_text = "Click a time to start!" if not self.flip_mode else "시간을 클릭해 시작하세요!"
        tk.Label(dialog, text=instr_text, font=("Helvetica", 14), bg="#121212", fg="#aaaaaa").pack(pady=(0, 30))

        times = [5, 10, 15, 20, 25, 30]
        for minutes in times:
            btn_text = f"{minutes} minutes" if not self.flip_mode else f"{minutes}분"
            btn = tk.Button(dialog, text=btn_text, font=("Helvetica", 15, "bold"), bg="#2d2d2d", fg="#ffffff", activebackground="#00e676", activeforeground="#000000", width=16, height=1, relief="flat", bd=0, highlightthickness=0, cursor="hand2", command=lambda m=minutes: self.launch_challenge(m, dialog))
            btn.pack(pady=7)

        cancel_text = "Cancel" if not self.flip_mode else "취소"
        tk.Button(dialog, text=cancel_text, font=("Helvetica", 12), bg="#404040", fg="#ffffff", activebackground="#505050", width=12, height=1, relief="flat", cursor="hand2", command=dialog.destroy).pack(pady=35)

    def launch_challenge(self, minutes, dialog):
        dialog.destroy()
        self.is_timed_mode = True
        self.time_limit_seconds = minutes * 60
        self.correct_count = 0
        self.total_attempted = 0
        self.deck = self.original_deck.copy()
        random.shuffle(self.deck)
        self.update_counter()
        self.timer_label.config(text="")
        self.feedback_main.config(text="")
        self.feedback_sub.config(text="")
        self.main_word_label.place_forget()
        self.countdown_label.place(relx=0.5, rely=0.5, anchor="center")
        self.run_countdown(3, minutes)

    def run_countdown(self, count, minutes):
        if count > 0:
            self.countdown_label.config(text=str(count))
            colors = ["#ffffff", "#ffff00", "#ff9800"]
            self.countdown_label.config(fg=colors[3 - count])
            self.root.after(1000, self.run_countdown, count - 1, minutes)
        else:
            go_text = "GO!" if not self.flip_mode else "시작!"
            self.countdown_label.config(text=go_text, fg="#00e676")
            self.root.after(800, self.start_challenge_after_go, minutes)

    def start_challenge_after_go(self, minutes):
        self.countdown_label.place_forget()
        self.main_word_label.place(relx=0.5, rely=0.5, anchor="center")
        self.start_time = time.time()
        self.timer_label.config(text=self.format_time(self.time_limit_seconds), fg="#ff9800")
        go_msg = f"GO! {minutes}-minute challenge started!" if not self.flip_mode else f"시작! {minutes}분 도전 시작!"
        self.feedback_main.config(text=go_msg, fg="#00e676")
        self.next_card()
        self.update_timer()

    def update_timer(self):
        if not self.is_timed_mode:
            return
        elapsed = time.time() - self.start_time
        remaining = max(0, self.time_limit_seconds - int(elapsed))
        if remaining <= 0:
            self.end_timed_challenge()
            return
        self.timer_label.config(text=self.format_time(remaining))
        if remaining <= 30:
            self.timer_label.config(fg="#ff5252")
        elif remaining <= 60:
            self.timer_label.config(fg="#ff9800")
        self.root.after(1000, self.update_timer)

    def format_time(self, seconds):
        mins = seconds // 60
        secs = seconds % 60
        return f"{mins:02d}:{secs:02d}"

    def end_timed_challenge(self):
        self.is_timed_mode = False
        self.timer_label.config(text="")
        accuracy = (self.correct_count / self.total_attempted * 100) if self.total_attempted > 0 else 0
        msg = f"Challenge Complete!\n\nCorrect: {self.correct_count}\nAttempted: {self.total_attempted}\nAccuracy: {accuracy:.1f}%\n\nGreat job! Back to normal mode." if not self.flip_mode else f"도전 완료!\n\n맞힌 개수: {self.correct_count}\n시도한 개수: {self.total_attempted}\n정확도: {accuracy:.1f}%\n\n잘했어요! 일반 모드로 돌아갑니다."
        messagebox.showinfo("Time's Up! 🎉" if not self.flip_mode else "시간 종료! 🎉", msg, parent=self.root)
        self.load_progress()
        self.update_counter()
        self.feedback_main.config(text="")
        self.feedback_sub.config(text="")
        if self.deck:
            self.next_card()
        else:
            done_text = "🎉 All done!\nGreat session!" if not self.flip_mode else "🎉 모두 완료!\n좋은 세션이었어요!"
            self.main_word_label.config(text=done_text, fg="#00e676")

    def save_progress(self):
        if self.is_timed_mode:
            return
        current_english = self.current_word["english"] if self.current_word else None
        progress = {
            "mastered": [w["english"] for w in self.mastered],
            "remaining": [w["english"] for w in self.deck],
            "current": current_english,
            "flip_mode": self.flip_mode
        }
        with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
            json.dump(progress, f)

    def load_progress(self):
        if not os.path.exists(PROGRESS_FILE):
            self.deck = self.original_deck.copy()
            random.shuffle(self.deck)
            return
        try:
            with open(PROGRESS_FILE, "r", encoding="utf-8") as f:
                progress = json.load(f)
            mastered_english = set(progress.get("mastered", []))
            remaining_english = set(progress.get("remaining", []))
            self.mastered = [w for w in self.original_deck if w["english"] in mastered_english]
            self.deck = [w for w in self.original_deck if w["english"] in remaining_english]
            current_english = progress.get("current")
            if current_english:
                for w in self.original_deck:
                    if w["english"] == current_english:
                        self.current_word = w
                        if w in self.deck:
                            self.deck.remove(w)
                        break
            saved_flip = progress.get("flip_mode", False)
            if saved_flip != self.flip_mode:
                self.flip_mode = saved_flip
            random.shuffle(self.deck)
        except Exception:
            messagebox.showerror("Load Error" if not self.flip_mode else "불러오기 오류", "Could not load progress. Starting fresh." if not self.flip_mode else "진행 상황을 불러올 수 없습니다. 새로 시작합니다.")
            self.deck = self.original_deck.copy()
            random.shuffle(self.deck)
            self.mastered = []
            self.current_word = None
            self.flip_mode = False

    def reset_deck(self):
        confirm_text = "Are you sure you want to reset all progress and start over?" if not self.flip_mode else "모든 진행 상황을 초기화하고 처음부터 다시 시작하시겠습니까?"
        if messagebox.askyesno("Reset Progress" if not self.flip_mode else "진행 초기화", confirm_text):
            self.deck = self.original_deck.copy()
            random.shuffle(self.deck)
            self.mastered = []
            self.current_word = None
            self.revealed_answer = False
            self.flip_mode = False
            self.flip_button.config(bg="#404040", fg="#ffffff")
            self.update_all_texts()
            if os.path.exists(PROGRESS_FILE):
                os.remove(PROGRESS_FILE)
            self.next_card()

    def quit_app(self):
        self.save_progress()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = FlashcardApp(root)
    root.mainloop()